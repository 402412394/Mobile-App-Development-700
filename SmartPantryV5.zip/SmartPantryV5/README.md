# Smart Pantry Manager

## Adding pantry ingredients

I added a form for entering a pantry item. It asks for an ingredient name and quantity, and lets me add a unit if I want to. The form checks that the name is filled in and the quantity is greater than zero before saving.

The screen saves the item through the local SQLite database.

