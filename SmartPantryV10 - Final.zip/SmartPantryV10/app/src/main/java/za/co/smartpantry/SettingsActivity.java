package za.co.smartpantry;

import android.app.*;
import android.os.Bundle;
import android.widget.*;

public class SettingsActivity extends Activity {
    @Override public void onCreate(Bundle b){super.onCreate(b);LinearLayout root=Ui.page(this,"Settings");root.addView(Ui.text(this,"Make the app feel right for you.",15));
        LinearLayout card=Ui.card(this);TextView title=Ui.text(this,"Expiry reminders",17);title.setTypeface(null,android.graphics.Typeface.BOLD);card.addView(title);TextView desc=Ui.text(this,"Preference saved on this device.",13);desc.setTextColor(Ui.MUTED);card.addView(desc);
        Switch alerts=new Switch(this);alerts.setText("Turn reminders on");alerts.setTextSize(15);alerts.setPadding(0,12,0,6);android.content.SharedPreferences p=getSharedPreferences("settings",MODE_PRIVATE);alerts.setChecked(p.getBoolean("expiry_alerts",false));alerts.setOnCheckedChangeListener((v,on)->p.edit().putBoolean("expiry_alerts",on).apply());card.addView(alerts);root.addView(card);
        root.addView(Ui.text(this,"This demo saves your reminder preference. Ingredient expiry dates and scheduled notifications are not included.",14));Button back=Ui.secondaryButton(this,"‹   Back to pantry");back.setOnClickListener(v->finish());root.addView(back);setContentView(root);}
}
