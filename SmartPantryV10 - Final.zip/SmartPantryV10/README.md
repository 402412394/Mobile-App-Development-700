# Smart Pantry Manager

Smart Pantry Manager is an offline Android app for keeping track of pantry ingredients and finding recipes that can be made with them. I used Java for the app and SQLite to save pantry items and recipe data on the device.

## What the app does

- Shows pantry ingredients with their quantities and units.
- Lets me add and edit ingredients. A name and positive quantity are required; the unit is optional.
- Lets me remove an item by long-pressing it in the pantry list and confirming the deletion.
- Suggests a recipe only when every ingredient listed for it is in the pantry with a quantity of at least one.
- Shows the ingredients and preparation steps for a selected recipe.
- Saves an expiry-reminder preference on the device. This is a demonstration setting only; expiry dates and scheduled notifications are not implemented.

Ingredient names are compared without case differences, extra spaces, or common singular and plural endings. Quantities are compared numerically, but the app does not convert units. I use consistent units for each ingredient.

## Why SQLite?

I chose SQLite because pantry information can stay on the device and the app can work offline. Android provides `SQLiteOpenHelper` to create and manage the local database. Pantry records are kept after the app is closed. The database also contains 18 starter recipes.

## Running the project

1. Install Android Studio, Android SDK 34, and JDK 17.
2. Open this folder as an existing Gradle project and wait for Gradle sync to finish.
3. Use an emulator running API 23 or later, or connect an Android device with USB debugging enabled.
4. Run the `app` configuration.

