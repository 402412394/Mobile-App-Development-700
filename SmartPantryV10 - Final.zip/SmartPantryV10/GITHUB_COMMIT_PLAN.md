# Development commit plan

Use these milestones if you are rebuilding the project for practice. Make each commit only after you have actually completed and reviewed that change. Do not manufacture an old timeline or claim that work happened on dates it did not.

1. `Create Java Android project and launch activity` - app skeleton and manifest.
2. `Add SQLite pantry and recipe schema` - database helper and seeded starter recipes.
3. `Display pantry items with custom adapter` - database-backed pantry list.
4. `Implement ingredient creation with validation` - required name, positive quantity, optional unit.
5. `Add ingredient editing and deletion` - complete CRUD interaction.
6. `Build strict recipe matching` - exclude every partial match and handle basic plural normalization.
7. `Add suggested recipe list and empty state` - dynamic results and no-match feedback.
8. `Create recipe detail screen and pass recipe ID` - ingredients, method, and Intent navigation.
9. `Add settings preference and navigation controls` - saved preference and cross-screen routes.
10. `Document setup, database choice, and demo steps` - update README and capture final genuine app screenshots.

If starting from the complete reference project, make honest, useful improvements before committing them (for example, add expiry dates, unit-aware recipe quantities, or tests if your course expects them). A list of suggested messages is not a substitute for real incremental work.
