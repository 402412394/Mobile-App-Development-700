# Smart Pantry Manager

## Updating the pantry

I connected the pantry list to the ingredient form so I can tap an item and change its details. Long-pressing an item opens a delete confirmation. The database helper handles adding items, saving edits, and removing records.

