package za.co.smartpantry;
import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;
public class MainActivity extends Activity {
    @Override public void onCreate(Bundle state) { super.onCreate(state); TextView welcome = new TextView(this); welcome.setText("Smart Pantry Manager"); setContentView(welcome); }
}
