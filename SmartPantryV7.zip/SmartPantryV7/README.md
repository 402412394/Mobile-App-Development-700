# Smart Pantry Manager

## Matching recipes to pantry items

I added the rule used to decide whether a recipe can be suggested. Every ingredient listed for a recipe has to be in the pantry, with a quantity of at least one. If even one is missing or short, the recipe is left out.

Ingredient names are compared without case differences or extra spaces, and common singular and plural endings are handled. Units are not converted, so quantities should use a consistent unit.

