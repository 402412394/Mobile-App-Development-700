# Smart Pantry Manager

## Android project and home screen

I set up the Android project and added the files needed to build and run it. The app currently opens to a basic home screen, which I’ll build on as I add more features. This includes the Gradle 8.13 wrapper, project and app Gradle files, the manifest, and the `MainActivity` class.

## SQLite database and pantry table

I added `PantryDb`, a helper class that extends Android’s `SQLiteOpenHelper`. It creates and manages the local database, including the table used to store pantry items.

## Recipe data

The app’s database includes 18 starter recipes, each with a name, ingredient list, and preparation steps. The `Recipe.java` model holds the recipe information, and `PantryDb` adds the recipes when the database is first created.

I copied `Recipe.java` and `PantryDb.java` from the completed reference project for this part.
