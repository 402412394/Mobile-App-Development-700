# Smart Pantry Manager

## Android project and home screen

I set up the Android project and added the files needed to build and run it. The app starts with a basic home screen, which I’m adding to as I work through the project. The setup includes the Gradle 8.13 wrapper, project and app Gradle files, the manifest, and the `MainActivity` class.

## SQLite database and recipes

`PantryDb` uses Android’s `SQLiteOpenHelper` to manage the local pantry database. It also includes the starter recipe data, with 18 recipes and their ingredients and preparation steps. `Recipe.java` represents each recipe.

## Pantry list

I updated the home screen to show pantry items saved in the database. Each row displays the ingredient name, quantity, and unit. The screen also includes common layout and style helpers in `Ui.java`.


