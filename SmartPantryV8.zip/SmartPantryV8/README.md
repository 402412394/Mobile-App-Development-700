# Smart Pantry Manager

## Suggested recipes

I added a screen that shows recipes only when all their listed ingredients are available in the pantry. If nothing matches, the screen explains that there are no recipes to show yet.

The results come from the matching logic in `PantryDb`, so the suggestions depend on the ingredients saved on the device.
