package za.co.smartpantry;

import android.app.*;
import android.content.*;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import java.util.List;

public class MainActivity extends Activity {
    PantryDb db; ListView list; TextView empty;
    @Override public void onCreate(Bundle b) { super.onCreate(b); db=new PantryDb(this); render(); }
    @Override protected void onResume() { super.onResume(); if(db!=null) refresh(); }
    void render() {
        LinearLayout root=Ui.page(this,"Your pantry");
        LinearLayout hero=Ui.card(this);hero.setBackground(Ui.shape(Ui.INK,22));
        TextView heroTag=Ui.text(this,"LESS WASTE  ·  MORE GOOD MEALS",11);heroTag.setTextColor(0xFFB9D8B9);heroTag.setTypeface(null,android.graphics.Typeface.BOLD);heroTag.setLetterSpacing(.06f);
        TextView heroText=Ui.text(this,"Good food starts\nwith what you have.",23);heroText.setTextColor(0xFFFFFFFF);heroText.setTypeface(null,android.graphics.Typeface.BOLD);
        TextView heroHint=Ui.text(this,"Keep track of ingredients and find recipes that need every item.",14);heroHint.setTextColor(0xFFE0E9E1);
        hero.addView(heroTag);hero.addView(heroText);hero.addView(heroHint);root.addView(hero);
        Button add=Ui.accentButton(this,"＋   Add an ingredient"); add.setOnClickListener(v -> startActivity(new Intent(this,EditIngredientActivity.class))); LinearLayout.LayoutParams addLp=new LinearLayout.LayoutParams(-1,-2);addLp.setMargins(0,14,0,4);root.addView(add,addLp);
        LinearLayout actions=new LinearLayout(this); Button suggestions=Ui.button(this,"Find recipes"); Button settings=Ui.secondaryButton(this,"Settings");
        suggestions.setOnClickListener(v -> startActivity(new Intent(this,SuggestedRecipesActivity.class))); settings.setOnClickListener(v -> startActivity(new Intent(this,SettingsActivity.class)));
        LinearLayout.LayoutParams actionLp=new LinearLayout.LayoutParams(0,-2,1);actionLp.setMargins(0,2,6,4);actions.addView(suggestions,actionLp);LinearLayout.LayoutParams secondLp=new LinearLayout.LayoutParams(0,-2,1);secondLp.setMargins(6,2,0,4);actions.addView(settings,secondLp);root.addView(actions);
        root.addView(Ui.section(this,"On your shelf  ·  tap to edit, hold to remove"));
        empty=Ui.text(this,"Your pantry is empty for now. Add a few ingredients to get started.",15);empty.setTextColor(Ui.MUTED); root.addView(empty);
        list=new ListView(this);list.setDivider(null);list.setDividerHeight(0);list.setSelector(android.R.color.transparent);list.setClipToPadding(false);list.setPadding(0,0,0,4);root.addView(list,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root); refresh();
    }
    void refresh() {
        if(list==null) return;
        List<PantryDb.Item> items=db.getPantry(); empty.setVisibility(items.isEmpty()?View.VISIBLE:View.GONE);
        list.setAdapter(new BaseAdapter() {
            public int getCount(){return items.size();} public Object getItem(int p){return items.get(p);} public long getItemId(int p){return items.get(p).id;}
            public View getView(int p,View old,android.view.ViewGroup parent){ PantryDb.Item x=items.get(p);LinearLayout row=new LinearLayout(MainActivity.this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(12,10,14,10);row.setBackground(Ui.shape(0xFFFFFFFF,16));row.setElevation(1);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,4,0,4);row.setLayoutParams(lp);
                TextView icon=Ui.badge(MainActivity.this,x.name.substring(0,1).toUpperCase());LinearLayout.LayoutParams iconLp=new LinearLayout.LayoutParams(44,44);iconLp.setMargins(0,0,13,0);row.addView(icon,iconLp);
                LinearLayout labels=new LinearLayout(MainActivity.this);labels.setOrientation(LinearLayout.VERTICAL);TextView name=Ui.text(MainActivity.this,x.name,16);name.setTypeface(null,android.graphics.Typeface.BOLD);name.setPadding(0,0,0,2);String amount=String.valueOf(x.quantity)+(x.unit.isEmpty()?"":" "+x.unit);TextView qty=Ui.text(MainActivity.this,amount,13);qty.setTextColor(Ui.MUTED);qty.setPadding(0,0,0,0);labels.addView(name);labels.addView(qty);row.addView(labels,new LinearLayout.LayoutParams(0,-2,1));TextView chevron=Ui.text(MainActivity.this,"›",28);chevron.setTextColor(Ui.GREEN);chevron.setPadding(8,0,0,0);row.addView(chevron);return row; }
        });
        list.setOnItemClickListener((a,v,pos,id)->{Intent i=new Intent(this,EditIngredientActivity.class); i.putExtra("item_id",id); startActivity(i);});
        list.setOnItemLongClickListener((a,v,pos,id)->{new AlertDialog.Builder(this).setTitle("Delete ingredient?").setMessage(items.get(pos).name).setNegativeButton("Cancel",null).setPositiveButton("Delete",(d,w)->{db.deleteItem(id);refresh();}).show();return true;});
    }
}
