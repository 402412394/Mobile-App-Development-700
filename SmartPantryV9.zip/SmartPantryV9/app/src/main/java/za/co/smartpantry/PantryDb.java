package za.co.smartpantry;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

public class PantryDb extends SQLiteOpenHelper {
    private static final String DB = "smart_pantry.db";
    public PantryDb(Context c) { super(c, DB, null, 1); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE pantry (_id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, quantity REAL NOT NULL, unit TEXT NOT NULL)");
        db.execSQL("CREATE TABLE recipes (_id INTEGER PRIMARY KEY, name TEXT NOT NULL, ingredients TEXT NOT NULL, steps TEXT NOT NULL)");
        seed(db);
    }
    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) { }

    private void seed(SQLiteDatabase db) {
        String[][] data = {
            {"Tomato pasta", "tomato,pasta,garlic,olive oil", "Boil pasta. Cook chopped tomato and garlic in olive oil, then toss with pasta."},
            {"Simple omelette", "egg,milk,salt,butter", "Beat eggs with milk and salt. Cook gently in melted butter until set."},
            {"Banana pancakes", "banana,egg,flour,milk", "Mash banana, whisk with egg, flour and milk, then cook small pancakes."},
            {"Garlic rice", "rice,garlic,oil,salt", "Cook rice. Sauté garlic in oil, stir through rice and season."},
            {"Cheese toast", "bread,cheese,butter", "Butter bread, add cheese and toast until golden and melted."},
            {"Tomato salad", "tomato,onion,olive oil,salt", "Chop tomato and onion, dress with olive oil and salt."},
            {"Potato mash", "potato,milk,butter,salt", "Boil peeled potato until soft. Mash with milk, butter and salt."},
            {"Apple porridge", "oats,apple,milk", "Simmer oats in milk. Top with chopped apple."},
            {"Lemon tea", "tea,lemon,honey", "Brew tea, then add lemon and honey to taste."},
            {"Bean tomato stew", "beans,tomato,onion,oil,salt", "Sauté onion in oil. Add tomato and beans; simmer and season."},
            {"Carrot soup", "carrot,onion,stock,salt", "Simmer chopped carrot and onion in stock until tender; blend and season."},
            {"Peanut banana smoothie", "banana,milk,peanut butter", "Blend banana, milk and peanut butter until smooth."},
            {"Egg fried rice", "rice,egg,oil,soy sauce", "Scramble egg in oil, add cooked rice and soy sauce, then stir-fry."},
            {"Cucumber salad", "cucumber,yogurt,lemon,salt", "Slice cucumber. Mix yogurt, lemon and salt into a dressing."},
            {"Flour flatbread", "flour,water,salt,oil", "Mix flour, water and salt into dough. Roll flat and pan-cook with a little oil."},
            {"Baked potato", "potato,oil,salt", "Rub potato with oil and salt. Bake until tender."},
            {"Honey oats", "oats,milk,honey", "Simmer oats in milk and finish with honey."},
            {"Tomato egg scramble", "egg,tomato,onion,oil,salt", "Sauté onion and tomato in oil. Add beaten eggs and stir until cooked."}
        };
        for (int i = 0; i < data.length; i++) {
            ContentValues v = new ContentValues(); v.put("_id", i + 1); v.put("name", data[i][0]);
            v.put("ingredients", data[i][1]); v.put("steps", data[i][2]); db.insert("recipes", null, v);
        }
    }

    public static class Item { public long id; public String name, unit; public double quantity; }
    public List<Item> getPantry() {
        List<Item> out = new ArrayList<>();
        try (Cursor c = getReadableDatabase().rawQuery("SELECT _id,name,quantity,unit FROM pantry ORDER BY name COLLATE NOCASE", null)) {
            while (c.moveToNext()) { Item x = new Item(); x.id=c.getLong(0); x.name=c.getString(1); x.quantity=c.getDouble(2); x.unit=c.getString(3); out.add(x); }
        } return out;
    }
    public Item getItem(long id) {
        try (Cursor c=getReadableDatabase().rawQuery("SELECT _id,name,quantity,unit FROM pantry WHERE _id=?", new String[]{String.valueOf(id)})) {
            if (c.moveToFirst()) { Item x=new Item(); x.id=c.getLong(0); x.name=c.getString(1); x.quantity=c.getDouble(2); x.unit=c.getString(3); return x; }
        } return null;
    }
    public long saveItem(long id, String name, double qty, String unit) {
        ContentValues v=new ContentValues(); v.put("name", name.trim()); v.put("quantity", qty); v.put("unit", unit.trim());
        if (id < 0) return getWritableDatabase().insert("pantry", null, v);
        return getWritableDatabase().update("pantry", v, "_id=?", new String[]{String.valueOf(id)}) > 0 ? id : -1;
    }
    public void deleteItem(long id) { getWritableDatabase().delete("pantry", "_id=?", new String[]{String.valueOf(id)}); }

    public List<Recipe> getMatchingRecipes() {
        List<Recipe> all=new ArrayList<>(), matches=new ArrayList<>();
        try (Cursor c=getReadableDatabase().rawQuery("SELECT _id,name,ingredients,steps FROM recipes ORDER BY name", null)) {
            while(c.moveToNext()) all.add(new Recipe(c.getInt(0),c.getString(1),c.getString(2),c.getString(3)));
        }
        List<Item> pantry=getPantry();
        for (Recipe r : all) {
            boolean qualifies=true;
            for (String required : r.ingredients) {
                double have=0; String key=normalize(required);
                for (Item item : pantry) if (normalize(item.name).equals(key)) have += item.quantity;
                if (have < 1.0) { qualifies=false; break; }
            }
            if (qualifies) matches.add(r);
        } return matches;
    }
    public Recipe getRecipe(int id) {
        try (Cursor c=getReadableDatabase().rawQuery("SELECT _id,name,ingredients,steps FROM recipes WHERE _id=?", new String[]{String.valueOf(id)})) {
            if(c.moveToFirst()) return new Recipe(c.getInt(0),c.getString(1),c.getString(2),c.getString(3));
        } return null;
    }
    public static String normalize(String value) {
        String s=value.toLowerCase(Locale.ROOT).trim().replaceAll("[^a-z0-9 ]", "").replaceAll("\\s+", " ");
        if (s.endsWith("ies") && s.length()>4) return s.substring(0,s.length()-3)+"y";
        if (s.endsWith("oes") && s.length()>4) return s.substring(0,s.length()-2);
        if (s.endsWith("s") && !s.endsWith("ss") && s.length()>3) return s.substring(0,s.length()-1);
        return s;
    }
}
