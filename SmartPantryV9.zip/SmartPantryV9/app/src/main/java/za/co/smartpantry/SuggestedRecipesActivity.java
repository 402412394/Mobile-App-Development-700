package za.co.smartpantry;

import android.app.*;
import android.content.*;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import java.util.List;

public class SuggestedRecipesActivity extends Activity {
    @Override public void onCreate(Bundle b){super.onCreate(b);render();}
    @Override protected void onResume(){super.onResume();render();}
    void render(){PantryDb db=new PantryDb(this);List<Recipe> recipes=db.getMatchingRecipes();LinearLayout root=Ui.page(this,"Recipes for today");
        LinearLayout note=Ui.card(this);note.setBackground(Ui.shape(Ui.PALE,18));TextView noteTitle=Ui.text(this,"Only complete matches",15);noteTitle.setTypeface(null,android.graphics.Typeface.BOLD);noteTitle.setTextColor(Ui.GREEN);note.addView(noteTitle);TextView noteBody=Ui.text(this,"Every ingredient must already be in your pantry.",13);noteBody.setTextColor(Ui.INK);note.addView(noteBody);root.addView(note);
        root.addView(Ui.section(this,recipes.size()+" recipes ready to make"));
        if(recipes.isEmpty()){LinearLayout empty=Ui.card(this);TextView icon=Ui.badge(this,"＋");LinearLayout.LayoutParams badgeLp=new LinearLayout.LayoutParams(54,54);empty.addView(icon,badgeLp);TextView title=Ui.text(this,"Nothing matches just yet",18);title.setTypeface(null,android.graphics.Typeface.BOLD);empty.addView(title);TextView msg=Ui.text(this,"Add a few more pantry ingredients and your recipe ideas will show up here.",14);msg.setTextColor(Ui.MUTED);empty.addView(msg);root.addView(empty);}
        else {ListView list=new ListView(this);list.setDivider(null);list.setDividerHeight(0);list.setSelector(android.R.color.transparent);list.setClipToPadding(false);list.setPadding(0,0,0,4);list.setAdapter(new BaseAdapter(){public int getCount(){return recipes.size();}public Object getItem(int p){return recipes.get(p);}public long getItemId(int p){return recipes.get(p).id;}public View getView(int p,View old,android.view.ViewGroup parent){Recipe r=recipes.get(p);LinearLayout card=Ui.card(SuggestedRecipesActivity.this);card.setOrientation(LinearLayout.HORIZONTAL);card.setGravity(Gravity.CENTER_VERTICAL);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,4,0,4);card.setLayoutParams(lp);TextView badge=Ui.badge(SuggestedRecipesActivity.this,"✓");card.addView(badge,new LinearLayout.LayoutParams(44,44));LinearLayout labels=new LinearLayout(SuggestedRecipesActivity.this);labels.setOrientation(LinearLayout.VERTICAL);labels.setPadding(13,0,0,0);TextView name=Ui.text(SuggestedRecipesActivity.this,r.name,16);name.setTypeface(null,android.graphics.Typeface.BOLD);name.setPadding(0,0,0,3);TextView meta=Ui.text(SuggestedRecipesActivity.this,r.ingredients.size()+" ingredients  ·  View recipe  ›",12);meta.setTextColor(Ui.MUTED);meta.setPadding(0,0,0,0);labels.addView(name);labels.addView(meta);card.addView(labels);return card;}});
            list.setOnItemClickListener((a,v,pos,id)->{Intent i=new Intent(this,RecipeDetailActivity.class);i.putExtra("recipe_id",(int)id);startActivity(i);});root.addView(list,new LinearLayout.LayoutParams(-1,0,1));}
        Button back=Ui.secondaryButton(this,"‹   Back to pantry");back.setOnClickListener(v->finish());root.addView(back);setContentView(root);
    }
}
