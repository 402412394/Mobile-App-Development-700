package za.co.smartpantry;

import java.util.Arrays;
import java.util.List;

public class Recipe {
    public final int id;
    public final String name;
    public final List<String> ingredients;
    public final String steps;

    public Recipe(int id, String name, String ingredients, String steps) {
        this.id = id;
        this.name = name;
        this.ingredients = Arrays.asList(ingredients.split("\\s*,\\s*"));
        this.steps = steps;
    }
}
