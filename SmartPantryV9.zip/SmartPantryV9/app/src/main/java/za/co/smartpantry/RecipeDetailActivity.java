package za.co.smartpantry;

import android.app.*;
import android.os.Bundle;
import android.widget.*;

public class RecipeDetailActivity extends Activity {
    @Override public void onCreate(Bundle b){super.onCreate(b);int id=getIntent().getIntExtra("recipe_id",-1);Recipe r=new PantryDb(this).getRecipe(id);LinearLayout root=Ui.page(this,r==null?"Recipe not found":r.name);
        if(r!=null){TextView intro=Ui.text(this,"A recipe you can make with what is already at home.",14);intro.setTextColor(Ui.MUTED);root.addView(intro);
            LinearLayout ingredients=Ui.card(this);TextView heading=Ui.section(this,"What you need");heading.setPadding(0,0,0,7);ingredients.addView(heading);for(String ingredient:r.ingredients){TextView item=Ui.text(this,"●   "+ingredient+"     ·     1 unit",15);item.setTextColor(Ui.INK);ingredients.addView(item);}root.addView(ingredients);
            LinearLayout method=Ui.card(this);LinearLayout.LayoutParams mlp=new LinearLayout.LayoutParams(-1,-2);mlp.setMargins(0,12,0,0);method.setLayoutParams(mlp);TextView methodHeading=Ui.section(this,"How to make it");methodHeading.setPadding(0,0,0,5);method.addView(methodHeading);method.addView(Ui.text(this,r.steps,15));root.addView(method);}
        Button back=Ui.secondaryButton(this,"‹   Back to recipes");back.setOnClickListener(v->finish());LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,12,0,0);root.addView(back,lp);setContentView(root);}
}
