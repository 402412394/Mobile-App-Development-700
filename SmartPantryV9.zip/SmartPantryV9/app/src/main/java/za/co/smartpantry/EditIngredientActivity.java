package za.co.smartpantry;

import android.app.*;
import android.os.Bundle;
import android.widget.*;

public class EditIngredientActivity extends Activity {
    PantryDb db; long id=-1; EditText name,quantity,unit;
    @Override public void onCreate(Bundle b) { super.onCreate(b); db=new PantryDb(this); id=getIntent().getLongExtra("item_id",-1); PantryDb.Item item=id<0?null:db.getItem(id);
        LinearLayout root=Ui.page(this,item==null?"Add ingredient":"Edit ingredient");
        root.addView(Ui.text(this,"Add what you have on hand. You can update it any time.",15));
        name=field("Ingredient name (e.g. tomatoes)"); quantity=field("Quantity (must be greater than 0)"); unit=field("Unit (optional: g, ml, pieces)");
        LinearLayout form=Ui.card(this);TextView label=Ui.section(this,"Ingredient details");label.setPadding(0,0,0,4);form.addView(label);form.addView(name);form.addView(quantity);form.addView(unit);root.addView(form);
        if(item!=null){name.setText(item.name);quantity.setText(String.valueOf(item.quantity));unit.setText(item.unit);}
        Button save=Ui.accentButton(this,"Save ingredient"); save.setOnClickListener(v->save());LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,14,0,3);root.addView(save,lp);
        Button cancel=Ui.secondaryButton(this,"Cancel"); cancel.setOnClickListener(v->finish());root.addView(cancel);setContentView(root);
    }
    EditText field(String hint){EditText e=new EditText(this);e.setSingleLine(true);e.setHint(hint);e.setTextSize(15);e.setPadding(14,10,14,10);e.setBackground(Ui.shape(0xFFF5F7F3,12));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,5,0,5);e.setLayoutParams(lp);return e;}
    void save(){String n=name.getText().toString().trim(),q=quantity.getText().toString().trim(),u=unit.getText().toString().trim();
        if(n.isEmpty()){name.setError("Enter an ingredient name");return;} if(q.isEmpty()){quantity.setError("Enter a quantity");return;}
        double amount;try{amount=Double.parseDouble(q);}catch(NumberFormatException ex){quantity.setError("Enter a valid number");return;} if(amount<=0){quantity.setError("Quantity must be greater than zero");return;}
        db.saveItem(id,n,amount,u);finish();
    }
}
