package za.co.smartpantry;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.content.res.ColorStateList;
import android.app.Activity;

final class Ui {
    static final int PAD=22;
    static final int INK=0xFF203A30;
    static final int GREEN=0xFF2F6B4F;
    static final int PALE=0xFFE5EFE5;
    static final int CREAM=0xFFF6F2E9;
    static final int ORANGE=0xFFC96F42;
    static final int MUTED=0xFF6F7C72;
    static LinearLayout page(Context c, String title) {
        if(c instanceof Activity){Activity a=(Activity)c;a.getWindow().setStatusBarColor(INK);a.getWindow().setNavigationBarColor(INK);}
        LinearLayout root=new LinearLayout(c); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(PAD,PAD,PAD,PAD); root.setBackgroundColor(CREAM);
        TextView eyebrow=new TextView(c);eyebrow.setText("SMART PANTRY  /  COOK WITH WHAT YOU HAVE");eyebrow.setTextSize(10);eyebrow.setLetterSpacing(.09f);eyebrow.setTypeface(null,Typeface.BOLD);eyebrow.setTextColor(GREEN);eyebrow.setPadding(0,0,0,5);root.addView(eyebrow);
        TextView h=new TextView(c); h.setText(title); h.setTextSize(29); h.setTypeface(null,Typeface.BOLD); h.setTextColor(INK); h.setPadding(0,0,0,13); root.addView(h); return root;
    }
    static Button button(Context c, String text) { return styledButton(c,text,GREEN,0xFFFFFFFF); }
    static Button accentButton(Context c,String text){return styledButton(c,text,ORANGE,0xFFFFFFFF);}
    static Button secondaryButton(Context c,String text){return styledButton(c,text,PALE,GREEN);}
    private static Button styledButton(Context c,String text,int fill,int ink){Button b=new Button(c);b.setText(text);b.setAllCaps(false);b.setTextSize(14);b.setTypeface(null,Typeface.BOLD);b.setTextColor(ink);b.setPadding(16,10,16,10);b.setMinHeight(50);b.setBackground(shape(fill,16));b.setStateListAnimator(null);return b;}
    static TextView text(Context c, String s, float size) { TextView t=new TextView(c); t.setText(s); t.setTextSize(size); t.setTextColor(INK); t.setPadding(0,7,0,7); return t; }
    static TextView section(Context c,String s){TextView t=text(c,s.toUpperCase(),12);t.setTypeface(null,Typeface.BOLD);t.setLetterSpacing(.08f);t.setTextColor(MUTED);t.setPadding(2,14,0,7);return t;}
    static LinearLayout card(Context c){LinearLayout box=new LinearLayout(c);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(16,13,16,13);box.setBackground(shape(0xFFFFFFFF,18));box.setElevation(2);return box;}
    static GradientDrawable shape(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(radius);return d;}
    static TextView badge(Context c,String value){TextView t=new TextView(c);t.setText(value);t.setTextColor(GREEN);t.setTextSize(16);t.setTypeface(null,Typeface.BOLD);t.setGravity(Gravity.CENTER);t.setBackground(shape(PALE,100));return t;}
    static void nav(Context c, LinearLayout root) {
        LinearLayout row=new LinearLayout(c); row.setGravity(Gravity.CENTER); row.setOrientation(LinearLayout.HORIZONTAL);
        Button pantry=button(c,"Pantry"), recipes=button(c,"Suggestions"), settings=button(c,"Settings");
        pantry.setOnClickListener(v -> ((android.app.Activity)c).finish());
        recipes.setOnClickListener(v -> c.startActivity(new android.content.Intent(c,SuggestedRecipesActivity.class)));
        settings.setOnClickListener(v -> c.startActivity(new android.content.Intent(c,SettingsActivity.class)));
        row.addView(pantry,new LinearLayout.LayoutParams(0,-2,1)); row.addView(recipes,new LinearLayout.LayoutParams(0,-2,1)); row.addView(settings,new LinearLayout.LayoutParams(0,-2,1)); root.addView(row);
    }
    static void click(View v, Runnable run) { v.setOnClickListener(w -> run.run()); }
}
