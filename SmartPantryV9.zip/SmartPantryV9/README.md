# Smart Pantry Manager

## Recipe details and navigation

I added a details screen for viewing a recipe’s ingredients and preparation steps. The selected recipe’s ID is passed to the screen with an Android `Intent`, and the manifest registers the recipe-related activities so Android can open them.

This connects the suggested recipe list to the full recipe information. 